from menus.menu_principal import MenuPrincipal

if __name__ == "__main__":
    MenuPrincipal().mostrar()
