from modulos.vehiculo import Vehiculo
from repositorios.vehiculo_repo import RepositorioVehiculo
from tools.validadores import inputObligatorio, validarFecha, validarEntero, convertirPlaca
from database.connection import crearConexion


connection = crearConexion()
repo = RepositorioVehiculo(connection)

#Fuc. que permite registrar nuevos vehiculos 
def registrarVehiculo():
    print("\n--- REGISTRAR NUEVO VEHÍCULO ---")
    
    #creamos un diccionario con los datos que nos da el usuario
    datos = {
            "placa": convertirPlaca("Placa: "),
            "marca": inputObligatorio("Marca: "),
           "referencia": inputObligatorio("Referencia: "),
            "modelo": validarEntero("Modelo: "),
            "numero_chasis": inputObligatorio("Número de chasis: "),
            "numero_motor": inputObligatorio("Número de motor: "),
            "color": inputObligatorio("Color: "),
            "concesionario": inputObligatorio("Concesionario: "),
            "fecha_compra_vehiculo": validarFecha("Fecha de compra (DD/MM/AAAA): "),
            "tiempo_garantia": validarEntero("Garantía (meses): "),
            "fecha_compra_poliza_seguro": validarFecha("Fecha compra póliza: "),
            "proveedor_poliza_seguro": inputObligatorio("Proveedor póliza: "),
            "fecha_compra_segObligatorio": validarFecha("Fecha compra SOAT: "),
            "proveedor_segObligatorio": inputObligatorio("Proveedor SOAT: "),
            "activo": validarEntero("Activo (1=Sí / 2=No): ", ["1", "2"])
        }        
        
    vehiculo = Vehiculo(**datos)
    try:
        repo.guardar(vehiculo)
        print("✅ Vehículo registrado correctamente.")
    except Exception as e:
        # Si IntegrityError, el repo lo propagó
        if isinstance(e, Exception) and "Vehículo ya registrado" in str(e):
            print("❌ Error: el vehículo ya se encuentra registrado (placa repetida).")
        else:
            print("❌ Error al registrar vehículo:", e)
                  
                  
#Permite consultar la informacion de culquier vehiculo previamente registrado
def consultarVehiculo():
    print("\n=== CONSULTA DE VEHÍCULO ===\n")
    repo = RepositorioVehiculo(connection)
    
    placa = inputObligatorio("\nPlaca del vehículo a consultar: ").upper()
    vehiculo = repo.buscar_por_placa(placa)
    
    if vehiculo is None:
        print(f"⚠️ No se encontró ningún vehículo registrado con la placa {placa}.")
        return
    
    print(f"\n=== Información del Vehículo {placa} ===")
    etiquetas = [
        "Placa", "Marca", "Referencia", "Modelo", "Número chasis",
        "Número motor", "Color", "Concesionario", "Fecha compra",
        "Garantía (meses)", "Fecha póliza", "Proveedor póliza",
        "Fecha SOAT", "Proveedor SOAT", "Activo"        
    ]
    
    for etiqueta, valor in zip(etiquetas, vehiculo.infVehiculo()):
        print(f"{etiqueta} : {valor}")
    print()
    
#Permite actualizar el estado los vehiculos 
def actualizarEstadoVehiculo(connection):
    print("\n=== ACTUALIZAR ESTADO DEL VEHÍCULO ===\n")
    repo = RepositorioVehiculo(connection)
    
    placa = convertirPlaca("\nPlaca del vehículo a actualizar: ")
    vehiculo = repo.buscar_por_placa(placa)
    
    if vehiculo is None:
        print(f"⚠️ No se encontró ningún vehículo registrado con la placa {placa}.")
        return
    
    nuevo_estado = validarEntero("Nuevo estado (1=Activo, 2=Inactivo): ", ["1", "2"])
    repo.actualizar_estado(placa, int(nuevo_estado))
    print("✅ Estado del vehículo actualizado correctamente.")
    
#Permite actualizar las Polizas del vehculo 
def actualizarPolizaVehiculo(connection):
    print("\n--- ACTUALIZAR POLIZA ---")
    repo = RepositorioVehiculo(connection)
    
    placa = convertirPlaca("\nPlaca del vehículo a actualizar: ")    
    #Verificar que se ingrese un numero de placa 
    if not placa:
        print("⚠️ La placa no puede estar vacía.")
        return
    
    vehiculo = repo.buscar_por_placa(placa)
    if vehiculo is None:
        print(f"⚠️ No se encontró ningún vehículo registrado con la placa {placa}.")
        return    #Verificar la existencia del vehiculo en la Base de Datos
    
    
    #Mostrar Informacion actual 
    polizas = vehiculo.obtenerPolizas()
    print(f"Poliza de seguro actual: Fecha: {polizas['fecha_poliza']} | Proveedor: {polizas['proveedor_poliza']}")
    print(f"Seguro obligatorio actual: Fecha: {polizas['fecha_seguro_obligatorio']} | Proveedor: {polizas['proovedor_seguro_obligatorio']}")    
    
    #Solicitar actualizacionde de polizas
    nuevaFechaCompraPolizaSeguro = validarFecha("\nDigite fecha de la nueva poliza seguro (DD/MM/AAAA): ")
    nuevaProveedorPolizaSeguro = inputObligatorio("Digite el nombre del nuevo proveedor de la poliza seguro: ")
    nuevaFechaCompraSegObligatorio = validarFecha("Digite su fecha del nuevo seguro obligatorio (DD/MM/AAAA): ")
    nuevaProveedorSegObligatorio = inputObligatorio("Digite el nombre del nuevo proveedor del seguro obligatorio: ")

    # --- Actualizar el objeto en memoria ---
    vehiculo.actualizaPoliza(
        nueva_fecha_compra_poliza_seguro = nuevaFechaCompraPolizaSeguro,
        nueva_proveedor_poliza_seguro = nuevaProveedorPolizaSeguro,
        nueva_fecha_compra_segObligatorio = nuevaFechaCompraSegObligatorio,
        nueva_proveedor_segObligatorio = nuevaProveedorSegObligatorio
    )

    # --- Persistir usando el repo (repo espera un Vehiculo) ---
    try:
        repo.actualizar_poliza(vehiculo)
        print("✅ Pólizas actualizadas correctamente.")
    except Exception as e:
        print("❌ Error al actualizar pólizas:", e)
        
def listaVeiculosActivos(connection):
    repo = RepositorioVehiculo(connection)
    filas = repo.lista_activos()
    if not filas:
        print("\n⚠️ No existen vehículos activos registrados.")
        return

    print("\n--- LISTA DE VEHÍCULOS ACTIVOS ---")
    for row in filas:
        print(f"Placa: {row[0]} Marca: {row[1]} Referencia: {row[2]} Modelo: {row[3]} Color: {row[4]}")
    print(f"\nTotal vehículos activos: {len(filas)}")