from menus.menu_base import Menu
from servicios.mantenimiento_servicios import (
    registrarMantenimiento,
    consultarMantenimiento,
    actualizarMantenimiento,
    borrarMantenimiento
)

from interfaz_grafica.MainApp import ejecutar_interfaz

def abrirInterfazMantenimientos():
    print("\n ABRIENDO CONSULTA GRÁFICA DE MANTENIMIENTOS...")
    ejecutar_interfaz()   # ← abre la ventana PyQt5

class MenuMantenimientos(Menu):
    """
    Menú para gestionar mantenimientos.
    Usa herencia desde Menu y polimorfismo en salir().
    """

    def __init__(self):
        opciones = {
            "1": ("Registrar Mantenimiento", registrarMantenimiento),
            "2": ("Consultar Mantenimiento", consultarMantenimiento),
            "3": ("Actualizar Mantenimiento", actualizarMantenimiento),
            "4": ("Borrar Mantenimiento", borrarMantenimiento),
            "5": ("Consulta gráfica de todos los mantenimientos", abrirInterfazMantenimientos),
            "6": ("Volver al Menú Principal", self.salir)
        }

        super().__init__("🛠️ MÓDULO DE MANTENIMIENTOS 🛠️", opciones)

    def salir(self):
        print("\n🔙 Regresando al menú principal...\n")
        return "salir"
