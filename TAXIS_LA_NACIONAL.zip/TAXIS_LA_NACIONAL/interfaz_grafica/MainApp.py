import sys
import os
sys.path.append(os.path.dirname(__file__))
from PyQt5.QtWidgets import QMainWindow, QTableWidgetItem
from PyQt5.QtCore import Qt
from interfaz import Ui_MainWindow
from servicios import mantenimiento_servicios as ms

class MainApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.aplicar_estilos_tabla()
        header = self.ui.TablaMantenimientos.horizontalHeader()
        header.setDefaultAlignment(Qt.AlignCenter)
        header.setMinimumSectionSize(120)


        self.cargar_tabla()
        self.ui.TablaMantenimientos.setSortingEnabled(True)

    def cargar_tabla(self):
        columnas, registros = ms.obtener_todos_los_mantenimientos()

        self.ui.TablaMantenimientos.setColumnCount(len(columnas))
        self.ui.TablaMantenimientos.setRowCount(len(registros))
        self.ui.TablaMantenimientos.setHorizontalHeaderLabels(columnas)

        for f, reg in enumerate(registros):
            for c, valor in enumerate(reg):
                item = QTableWidgetItem(str(valor))
                item.setFlags(item.flags() ^ Qt.ItemIsEditable)
                self.ui.TablaMantenimientos.setItem(f, c, item)

    def aplicar_estilos_tabla(self):
        tabla = self.ui.TablaMantenimientos

        tabla.setStyleSheet("""
            QTableWidget {
                background-color: #F7F7F7;
                alternate-background-color: #E8E8E8;
                gridline-color: #CCCCCC;
                font-size: 13px;
                selection-background-color: #4A90E2;
                selection-color: white;
            }

            QHeaderView::section {
                background-color: #2C3E50;
                color: white;
                padding: 5px;
                border: none;
                font-weight: bold;
                font-size: 14px;
            }

            QTableWidget::item {
                padding: 6px;
            }
        """)

        # Activar filas alternadas
        tabla.setAlternatingRowColors(True)

        # Ajustar columnas automáticamente
        tabla.horizontalHeader().setStretchLastSection(True)
        tabla.resizeColumnsToContents()

        tabla.setStyleSheet("""
        QTableWidget {
            background: #fdfdfd;
            alternate-background-color: #f6f6f6;
            border: 1px solid #d0d0d0;
            border-radius: 6px;
            font-size: 14px;
            padding: 4px;
        }

        QTableWidget::item {
            padding: 8px;
            border-bottom: 1px solid #e0e0e0;
        }

        QTableWidget::item:selected {
            background-color: #3498db;
            color: white;
        }

        QHeaderView::section {
            background-color: #34495e;
            color: #ffffff;
            padding: 8px;
            border: none;
            font-size: 15px;
        }
    """)

def ejecutar_interfaz():
    from PyQt5.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    win = MainApp()
    win.show()
    sys.exit(app.exec_())
