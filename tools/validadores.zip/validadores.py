from datetime import datetime
    
def inputObligatorio (mensaje):
    #Pide input hasta que el usuario ingrese algo no vacío. Devuelve la cadena (strip).
    while True:
        entrada = input(mensaje).strip()
        if entrada == "":
            print(" ⚠️ Lo sentimos el campo no puede estar vacio, porfavor intente de nuevo.")
            print("Regresando al menu anterior...")
            #reintentar
            continue
        return entrada
            
def validarFecha(mensaje):
    # Valida formato DD/MM/AAAA. Reintenta hasta que sea válido,  devuelve la fecha en el formato DD/MM/YYYY (string).
    formato= "%d/%m/%Y"    
    while True:
        entrada = inputObligatorio(mensaje)
        try:
            datetime.strptime(entrada, formato)
            return entrada
        except ValueError:
            print("❌ Fecha invalida. Use el formato DD/MM/AAAA. Intente de nuevo.")

def validarEntero(mensaje, allowed_values=None):
    # Valida que la entrada sea un entero. Si allowed_values (lista de strings) se pasa,
    # verifica que la entrada esté dentro de allowed_values (ej. ["1","2"]).
    while True:
        entrada = inputObligatorio(mensaje)
        if allowed_values is not None:
            if entrada not in allowed_values:
                print(f"❌ Valor inválido. Opciones permitidas: {allowed_values}")
                continue
            return int(entrada)
        if entrada.isdigit():
            return int(entrada)
        else:
            print("❌ Ingrese un número entero válido.")

def convertirPlaca(mensaje):
    # Pide la placa y devuelve en MAYÚSCULAS y sin espacios extremos.    
    while True:
        entrada = input(mensaje).strip()
        if entrada == "":
            print(" ⚠️ Lo sentimos el campo no puede estar vacio, porfavor intente de nuevo. ")
            continue
        return entrada.upper()
